# راهنمای بیلد خودکار (GitHub Actions)

این پروژه دو workflow دارد:

- **`.github/workflows/build-and-release.yml`** (از قبل موجود در پروژه): بیلد **Debug** APK/AAB با `debug.keystore`، بدون نیاز به هیچ secret‌ی. برای تست سریع مناسب است، نه برای توزیع نهایی.
- **`.github/workflows/android-build.yml`** (جدید، طبق درخواست شما): بیلد **Release** APK با کلید امضای واقعی شما، فقط با push به شاخه `main`.

## مراحل آپلود در گیت‌هاب

1. یک مخزن (repository) جدید در GitHub بسازید.
2. محتویات این ZIP را در آن push کنید:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/javadsolvpn.git
   git push -u origin main
   ```
3. وارد تب **Settings → Secrets and variables → Actions** در ریپوی خود شوید و Secretهای زیر را اضافه کنید (برای بیلد Release ضروری است؛ بدون آن‌ها workflow جدید با خطا متوقف می‌شود):

   | نام Secret | توضیح |
   |---|---|
   | `ANDROID_KEYSTORE_BASE64` | خروجی base64 فایل keystore release شما (پایین توضیح داده شده) |
   | `ANDROID_STORE_PASSWORD` | پسورد فایل keystore |
   | `ANDROID_KEY_PASSWORD` | پسورد کلید (alias) داخل keystore — alias باید `upload` باشد (طبق تنظیمات `app/build.gradle.kts`) |

4. اگر هنوز keystore release ندارید، آن را بسازید:
   ```bash
   keytool -genkeypair -v -keystore my-upload-key.jks \
     -storepass YOUR_STORE_PASSWORD -keypass YOUR_KEY_PASSWORD \
     -alias upload -keyalg RSA -keysize 2048 -validity 10000
   ```
   ⚠️ این فایل را **هرگز** در گیت کامیت نکنید — از قبل در `.gitignore` قرار دارد. آن را جایی امن (مدیر رمز عبور، Secrets Manager) نگه دارید؛ گم‌شدنش یعنی دیگر نمی‌توانید نسخه‌های بعدی اپ را آپدیت کنید.

5. برای تولید مقدار `ANDROID_KEYSTORE_BASE64`:
   ```bash
   base64 -w0 my-upload-key.jks > keystore.base64.txt
   # محتوای keystore.base64.txt را کپی و در GitHub Secret بگذارید
   ```

6. با هر push به `main`، تب **Actions** باز می‌شود، workflow `Android Release Build` اجرا می‌شود و پس از چند دقیقه، artifact با نام `javadsolvpn-release-apk` قابل دانلود خواهد بود (داخل همان صفحه run، بخش Artifacts).

## نکته مهم درباره `libv2ray.aar`

پروژه به `app/libs/libv2ray.aar` نیاز دارد که در ZIP نیست (حجیم است و معمولاً در گیت commit نمی‌شود). هر دو workflow به طور خودکار نسخه pinned شده (`v26.10.21` از `2dust/AndroidLibXrayLite`) را در زمان بیلد دانلود می‌کنند — نیازی به کار دستی نیست.

## iOS

همان‌طور که در `README.md` پروژه توضیح داده شده، نسخه فعلی فقط Android (Kotlin/Jetpack Compose) است. ساخت iOS واقعی نیازمند یک پروژه جداگانه Xcode با Network Extension (Packet Tunnel Provider) و حساب Apple Developer است — این خارج از سورس فعلی است، بنابراین فایل `ios-build.yml` در این تحویل ساخته نشد (چیزی برای بیلد کردن روی iOS وجود ندارد). اگر سورس iOS را در آینده اضافه کردید، با کمال میل workflow معادل را می‌سازم.

## خلاصه تغییرات امنیتی اعمال‌شده در این تحویل

جزئیات کامل در `SECURITY-REVIEW.md`. خلاصه:

1. ✅ `*.jks` / `*.keystore` به `.gitignore` اضافه شد (جلوگیری از کامیت تصادفی کلید امضا)
2. ✅ دیتابیس محلی (حاوی اعتبارنامه سرورهای VPN) از Android Auto Backup مستثنی شد (`backup_rules.xml`, `data_extraction_rules.xml`)
3. ✅ workflow جدید `android-build.yml` برای بیلد Release امضاشده اضافه شد
4. ℹ️ چند توصیه (فعال‌سازی ProGuard/R8، آگاهی از منابع عمومی کشف سرور) که عمداً بدون تست در کد اعمال نشدند — در گزارش توضیح داده شده
