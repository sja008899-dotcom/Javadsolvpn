# گزارش بررسی امنیتی سورس کد — Javadsolvpn 1.0.8

تاریخ: 2026-10-25
نوع بررسی: بازبینی استاتیک سورس کد (AndroidManifest، Gradle، Kotlin) — بدون دیکامپایل یا مهندسی معکوس باینری، چون فایل ارسالی سورس کد خود شماست.

## خلاصه

پروژه به طور کلی ساختار امنیتی خوبی دارد: بدون `android:debuggable`، بدون `usesCleartextTraffic`، بدون کلید/توکن هاردکد شده، بدون کامپوننت exported غیرضروری، و بدون کد دور زدن SSL/TrustManager. دو مشکل واقعی پیدا و برطرف شد (پایین را ببینید)، و چند مورد به‌عنوان توصیه ثبت شده‌اند.

## جدول یافته‌ها

| # | عنوان | CWE | شدت | فایل | وضعیت |
|---|-------|-----|------|------|--------|
| 1 | کلید امضای Release (`*.jks`) در `.gitignore` نبود | CWE-798 (Use of Hard-coded Credentials) / CWE-312 | **High** | `.gitignore`, `app/build.gradle.kts` | ✅ اصلاح شد |
| 2 | اعتبارنامه‌های سرور VPN (uuid/password، Reality publicKey/shortId) در دیتابیس Room ذخیره می‌شوند و `allowBackup="true"` بدون exclude rule باعث می‌شد در Android Auto Backup / adb backup کپی شوند | CWE-312 (Cleartext Storage of Sensitive Information), CWE-530 | **Medium** | `AndroidManifest.xml`, `backup_rules.xml`, `data_extraction_rules.xml`, `ServerConfigEntity.kt` | ✅ اصلاح شد (exclude rules اضافه شد) |
| 3 | Release build با `isMinifyEnabled = false` ساخته می‌شود — بدون shrink/obfuscate | CWE-656 (Reliance on Security through Obscurity — نبود آن) | Low | `app/build.gradle.kts` | ℹ️ توصیه (اعمال نشد — ریسک شکستن بیلد بدون تست روی Android SDK واقعی) |
| 4 | منابع کشف سرور (Discovery Sources) پیش‌فرض از مخازن عمومی GitHub گرفته می‌شوند؛ محتوای این لیست‌ها غیرقابل‌اعتماد است و می‌تواند شامل سرورهای مخرب/مانیتورشده باشد | CWE-829 (Inclusion of Functionality from Untrusted Control Sphere) | Low (طراحی ذاتی این نوع اپ) | `AppDatabase.kt` | ℹ️ توصیه — فقط اطلاع‌رسانی، نیازی به تغییر کد ندارد |
| 5 | Workflow موجود (`build-and-release.yml`) خروجی APK را با **debug keystore** امضا کرده و به‌عنوان «Release» منتشر می‌کند | CWE-295 (Improper Certificate Validation) — از دید کاربر نهایی، امضای غیرقابل‌اعتماد | Medium | `.github/workflows/build-and-release.yml` | ℹ️ توصیه — workflow جدید `android-build.yml` با امضای واقعی اضافه شد؛ workflow قدیمی دست‌نخورده باقی ماند |

## جزئیات

### #1 — کلید امضا در gitignore نبود (اصلاح شد)
در `app/build.gradle.kts`، مسیر پیش‌فرض کلید امضا:
```kotlin
val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
```
این فایل در `.gitignore` نبود. اگر کسی بدون تنظیم `KEYSTORE_PATH` به صورت محلی بیلد می‌گرفت و کلید را در ریشه پروژه می‌ساخت، با یک `git add .` به‌راحتی به ریپو کامیت می‌شد. اصلاح: افزوده شدن `*.jks`, `*.keystore`, `my-upload-key.jks` به `.gitignore`.

### #2 — نشت اعتبارنامه VPN از طریق Backup (اصلاح شد)
`ServerConfigEntity` فیلدهایی مثل `uuidOrPassword`, `publicKey`, `shortId` را در دیتابیس SQLite محلی ذخیره می‌کند. `AndroidManifest.xml` دارای `android:allowBackup="true"` است و `backup_rules.xml` / `data_extraction_rules.xml` قبلاً هیچ exclude rule‌ای نداشتند — یعنی کل دیتابیس در Auto Backup (و `adb backup`) کپی می‌شد. اصلاح: افزودن قوانین exclude برای فایل‌های `javadsolvpn.db*` در هر دو فایل تنظیمات بکاپ.

### #3 — ProGuard/R8 در ریلیز غیرفعال است (فقط توصیه)
`isMinifyEnabled = false` یعنی کد در APK ریلیز shrink/obfuscate نمی‌شود. این مستقیماً یک آسیب‌پذیری نیست ولی تحلیل/مهندسی معکوس را ساده‌تر می‌کند. چون محیط من دسترسی به Android SDK کامل برای تست بیلد واقعی ندارد، این تغییر را اعمال نکردم تا ریسک شکستن بیلد شما را ایجاد نکنم؛ توصیه می‌شود خودتان `isMinifyEnabled = true` را با توجه به `proguard-rules.pro` موجود (که keep rule برای `libv2ray`/`go` دارد) تست کنید.

### #4 — منابع کشف سرور عمومی (فقط اطلاع‌رسانی)
این بخشی از طراحی عملکردی اپ شماست (پیدا کردن سرورهای رایگان V2Ray/Trojan از مخازن عمومی) و تغییر آن یعنی تغییر رفتار محصول، نه رفع یک باگ امنیتی کد. صرفاً به اطلاع می‌رسانم که کاربران باید بدانند این سرورها از منابع غیرقابل‌اعتماد شخص ثالث‌اند.

### #5 — Workflow قدیمی APK را با debug keystore امضا می‌کند
`build-and-release.yml` موجود در پروژه عمداً دست‌نخورده نگه داشته شد (طبق خواسته شما فقط قرار بود یک `android-build.yml` جدید اضافه شود)، اما لازم است بدانید: APK/AAB خروجی آن workflow با `debug.keystore` امضا می‌شود، نه کلید release واقعی. این یعنی اگر از آن artifact برای توزیع عمومی استفاده کنید، امضا قابل‌اعتماد و قابل‌به‌روزرسانی (update) با نسخه‌های آینده نخواهد بود. workflow جدید `android-build.yml` که اضافه شد، بیلد را با کلید release واقعی (از GitHub Secrets) امضا می‌کند — به `README-BUILD.md` مراجعه کنید.

## بررسی `.env` / gitignore (بخش ۲ درخواست شما)

- در ZIP ارسالی هیچ فایل `.env` واقعی وجود نداشت — فقط `.env.example` (که برای کلید Gemini API placeholder است و طبق کامنت داخلش، اگر خط مربوطه uncomment نشود در APK پکیج نمی‌شود).
- `.env` از قبل در `.gitignore` ریشه پروژه قرار داشت و درست ایگنور می‌شد. ✅
- `debug.keystore` هم در gitignore بود. ✅
- مشکل واقعی که پیدا شد، نبود `*.jks` (کلید release) بود که در بالا (#1) اصلاح شد.

## آنچه بررسی و **تأیید شد که مشکلی ندارد**

- بدون `android:debuggable="true"` در منبفست (پیشفرض صحیح برای ریلیز)
- بدون `usesCleartextTraffic` یا Network Security Config ناامن → پیشفرض امن (HTTPS-only از API 28 به بالا) برقرار است
- بدون کلید/توکن/پسورد هاردکد شده در Kotlin
- بدون پیاده‌سازی سفارشی `X509TrustManager`/`HostnameVerifier` برای دور زدن SSL pinning
- `VpnService` با `exported="false"` و `permission="android.permission.BIND_VPN_SERVICE"` — درست محافظت شده
- `MainActivity` با `exported="true"` فقط به این دلیل که LAUNCHER activity است — این استاندارد و لازم است
- همه `PendingIntent`ها با `FLAG_IMMUTABLE` ساخته شده‌اند — امن در برابر PendingIntent injection (CWE-926 رفع شده)
- بدون فراخوانی `Log.d/i/v/w/e` در کد — داده حساسی به logcat درز نمی‌کند
